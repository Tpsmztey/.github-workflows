package com.matheus.multihunt;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.webkit.ProfileStore;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import org.json.JSONTokener;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class MainActivity extends Activity {

    // Troque aqui se quiser outra URL
    private static final String URL = "https://huntera.com.br/";
    private static final int N = 4;

    private final WebView[] webs = new WebView[N];
    private final LinearLayout[] rows = new LinearLayout[2];
    private int focused = -1;
    private String autoJs = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        try {
            autoJs = readAsset("auto.js");
        } catch (IOException ignored) {
        }

        boolean multi = WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE);
        if (!multi) {
            Toast.makeText(this,
                    "Atualize o 'Android System WebView' na Play Store: sem isso as contas dividem o mesmo login.",
                    Toast.LENGTH_LONG).show();
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.BLACK);

        // Barra de botoes: 1 2 3 4 | grade | inspecionar | recarregar
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < N; i++) {
            final int idx = i;
            bar.addView(makeButton(String.valueOf(i + 1), v -> setFocus(idx)));
        }
        bar.addView(makeButton("\u25A6", v -> setFocus(-1)));
        bar.addView(makeButton("\uD83D\uDD0D", v -> inspect()));
        bar.addView(makeButton("\u27F3", v -> reload()));
        root.addView(bar, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(44)));

        // Grade 2x2
        for (int r = 0; r < 2; r++) {
            rows[r] = new LinearLayout(this);
            rows[r].setOrientation(LinearLayout.HORIZONTAL);
            root.addView(rows[r], new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
            for (int c = 0; c < 2; c++) {
                int idx = r * 2 + c;
                webs[idx] = createWebView(idx, multi);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                        0, LinearLayout.LayoutParams.MATCH_PARENT, 1f);
                lp.setMargins(1, 1, 1, 1);
                rows[r].addView(webs[idx], lp);
            }
        }

        setContentView(root);
    }

    private WebView createWebView(int i, boolean multi) {
        WebView w = new WebView(this);
        if (multi) {
            String name = "conta" + (i + 1);
            ProfileStore.getInstance().getOrCreateProfile(name);
            WebViewCompat.setProfile(w, name); // tem que vir antes de carregar qualquer coisa
        }
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setUserAgentString(s.getUserAgentString().replace("; wv", ""));
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, true);
        w.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                if (!autoJs.isEmpty()) view.evaluateJavascript(autoJs, null);
            }
        });
        w.loadUrl(URL);
        return w;
    }

    // Copia para a area de transferencia a lista de botoes/textos da conta em foco
    private void inspect() {
        int idx = focused >= 0 ? focused : 0;
        if (focused < 0) {
            Toast.makeText(this,
                    "Inspecionando a conta 1. Toque num numero antes para escolher outra.",
                    Toast.LENGTH_SHORT).show();
        }
        final String js;
        try {
            js = readAsset("inspect.js");
        } catch (IOException e) {
            Toast.makeText(this, "Nao achei inspect.js", Toast.LENGTH_LONG).show();
            return;
        }
        webs[idx].evaluateJavascript(js, value -> {
            String text = value == null ? "" : value;
            try {
                text = String.valueOf(new JSONTokener(value).nextValue());
            } catch (Exception ignored) {
            }
            ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("inspecao", text));
            Toast.makeText(this,
                    "Copiado (" + text.length() + " caracteres). Cole no chat.",
                    Toast.LENGTH_LONG).show();
        });
    }

    private String readAsset(String name) throws IOException {
        try (InputStream in = getAssets().open(name);
             ByteArrayOutputStream bo = new ByteArrayOutputStream()) {
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            return bo.toString("UTF-8");
        }
    }

    private Button makeButton(String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setPadding(0, 0, 0, 0);
        b.setOnClickListener(l);
        b.setLayoutParams(new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.MATCH_PARENT, 1f));
        return b;
    }

    private void setFocus(int f) {
        focused = f;
        for (int i = 0; i < N; i++) {
            webs[i].setVisibility((f < 0 || f == i) ? View.VISIBLE : View.GONE);
        }
        for (int r = 0; r < 2; r++) {
            rows[r].setVisibility((f < 0 || f / 2 == r) ? View.VISIBLE : View.GONE);
        }
    }

    private void reload() {
        if (focused >= 0) {
            webs[focused].reload();
        } else {
            for (WebView w : webs) w.reload();
        }
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    @Override
    public void onBackPressed() {
        if (focused >= 0) {
            if (webs[focused].canGoBack()) webs[focused].goBack();
            else setFocus(-1);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        for (WebView w : webs) {
            if (w != null) w.destroy();
        }
        super.onDestroy();
    }
}
