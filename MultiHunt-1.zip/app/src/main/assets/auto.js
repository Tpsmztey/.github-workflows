// Script de automacao, injetado em cada conta quando a pagina termina de carregar.
// Por enquanto vazio: sera preenchido depois de usar o botao de inspecao.
(function () {
  if (window.__multihuntAuto) return;
  window.__multihuntAuto = true;
})();
