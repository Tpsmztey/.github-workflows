(function () {
  function vis(e) {
    var r = e.getBoundingClientRect();
    var s = getComputedStyle(e);
    return r.width > 0 && r.height > 0 && s.visibility !== 'hidden' && s.display !== 'none';
  }
  function path(e) {
    var p = [];
    while (e && e.nodeType === 1 && p.length < 4) {
      var s = e.tagName.toLowerCase();
      if (e.id) { s += '#' + e.id; p.unshift(s); break; }
      var c = (typeof e.className === 'string' ? e.className : '').trim().split(/\s+/).filter(Boolean).slice(0, 2).join('.');
      if (c) s += '.' + c;
      p.unshift(s);
      e = e.parentElement;
    }
    return p.join(' > ');
  }
  function label(e) {
    return ((e.innerText || e.value || e.getAttribute('aria-label') || e.title || '') + '')
      .replace(/\s+/g, ' ').trim().slice(0, 40);
  }
  var out = [];
  out.push('URL: ' + location.href);
  out.push('TITULO: ' + document.title);
  out.push('--- TEXTO VISIVEL ---');
  out.push(((document.body && document.body.innerText) || '').replace(/\n{2,}/g, '\n').slice(0, 1500));
  out.push('--- ELEMENTOS CLICAVEIS ---');
  var sel = 'button,a,[role=button],input[type=button],input[type=submit],[onclick],[class*=btn],[class*=button]';
  var seen = new Set();
  var n = 0;
  document.querySelectorAll(sel).forEach(function (e) {
    if (n >= 80 || seen.has(e) || !vis(e)) return;
    seen.add(e); n++;
    out.push(n + ') [' + e.tagName.toLowerCase() + '] "' + label(e) + '" | ' + path(e));
  });
  var m = 0;
  document.querySelectorAll('body *').forEach(function (e) {
    if (m >= 60 || seen.has(e) || !vis(e)) return;
    if (getComputedStyle(e).cursor !== 'pointer') return;
    if (e.parentElement && getComputedStyle(e.parentElement).cursor === 'pointer') return;
    seen.add(e); m++;
    out.push('p' + m + ') [' + e.tagName.toLowerCase() + '] "' + label(e) + '" | ' + path(e));
  });
  return out.join('\n').slice(0, 12000);
})();
